---
name: summarize
description: "This skill should be used whenever the user provides one or more URLs and wants a concise, structured summary or digest of the content. Typical triggers: 帮我总结这篇文章, 整理这个链接的精华, 提炼要点, summarize this, give me the key points from these links. Also use when the user pastes multiple links and asks for a comparison or synthesis across sources."
---

# Summarize — URL Content Extraction & Digest

## Purpose

Fetch, read, and distill the core content from one or more URLs into a clean, structured summary. Deliver actionable insights, key facts, and essential takeaways — not just a restatement of the article.

## When to Use

Load this skill whenever:
- The user provides one or more URLs alongside a request to summarize, extract, or distill
- The user asks "整理精华", "提炼要点", "总结一下", "summarize", "key points", "TL;DR"
- The user pastes multiple links and wants a combined synthesis or comparison

## Workflow

### Step 1 — Parse the Request

Identify:
1. **URLs**: Extract all links the user provided
2. **Output format**: Does the user want bullet points, a table, a narrative summary, a comparison?
3. **Focus area**: Is there a specific angle (e.g., "只看技术参数", "关注价格", "找争议点")?
4. **Output language**: Match the user's language (中文/英文/bilingual)

If the user gave no format preference, default to **structured Markdown with headings + bullet key points**.

### Step 2 — Fetch Content

For each URL:
1. Use the `web_fetch` tool to retrieve the page content
2. If a URL redirects, follow the redirect and fetch the final destination
3. If a URL is inaccessible (paywall, 403, timeout), note it clearly and skip gracefully

For multiple URLs (≥3), fetch them in parallel where possible.

### Step 3 — Extract & Distill

For each fetched page, extract:

| Element | What to Capture |
|---------|----------------|
| **Core claim / thesis** | The single most important point the article makes |
| **Key facts & data** | Numbers, dates, names, statistics — concrete and verifiable |
| **Arguments / reasoning** | Main supporting points the author uses |
| **Conclusions / recommendations** | What the author suggests the reader do or think |
| **Caveats / limitations** | What the author admits the piece doesn't cover |
| **Notable quotes** | 1–2 sentences worth quoting verbatim (only if genuinely insightful) |

**What to skip:**
- Boilerplate headers, navigation, ads, cookie notices
- Repetitive filler phrases
- Promotional language without substance

### Step 4 — Synthesize (Multi-URL Mode)

When summarizing multiple URLs on the same topic:
1. **Identify common ground**: What do all sources agree on?
2. **Surface disagreements**: Where do sources contradict each other?
3. **Fill gaps**: What does each source cover that others miss?
4. **Rank sources**: Which source is most authoritative / most recent / most detailed?

### Step 5 — Format Output

#### Single URL — Standard Format

```
## [Article Title or Topic] — Summary

**来源**: [URL]
**发布时间**: [date if available]
**核心观点**: [one sentence]

### 关键要点
- [point 1]
- [point 2]
- [point 3]
...

### 数据 & 事实
- [fact/number 1]
- [fact/number 2]

### 结论 / 建议
[1-2 sentences]

### 值得关注
[Optional: caveats, surprises, or things to investigate further]
```

#### Multiple URLs — Synthesis Format

```
## 综合摘要：[Topic]

### 共同结论
[What all sources agree on]

### 各方观点对比
| 来源 | 核心观点 | 支持数据 |
|------|---------|---------|
| [source 1] | ... | ... |
| [source 2] | ... | ... |

### 分歧点
[Where sources disagree and why]

### 综合建议 / 结论
[Synthesized takeaway across all sources]

### 来源列表
1. [URL 1] — [one-line description]
2. [URL 2] — [one-line description]
```

### Step 6 — Quality Check Before Delivering

Before sending the summary, verify:
- [ ] Every key point is grounded in the actual fetched content (no hallucination)
- [ ] Data/numbers are quoted exactly as they appear in the source
- [ ] The summary adds value — it's shorter and clearer than the original
- [ ] Output language matches the user's request

## Failure Modes & Handling

| Situation | Action |
|-----------|--------|
| URL returns 403/404 | Note "无法访问" and continue with other URLs |
| Paywall content (only teaser visible) | Summarize what's visible, note "内容受限，仅摘要可见" |
| Non-article URL (homepage, app store) | State "此链接为非文章页面" and describe what was found |
| Very long article (>5000 words) | Focus on introduction, headings, and conclusion sections |
| Content in foreign language | Translate key points into the user's preferred language |

## Output Length Guidelines

| Source Count | Target Length |
|-------------|---------------|
| 1 URL | 200–500 words |
| 2–3 URLs | 400–800 words |
| 4+ URLs | 600–1200 words, or ask user if they want individual vs. synthesized summaries |

Keep summaries tight. If the user wants more depth on a section, they'll ask.
