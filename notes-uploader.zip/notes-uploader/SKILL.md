---
name: notes-uploader
description: "This skill should be used when the user wants to import knowledge notes into the weekly-schedule PWA app (index.html). It reads the user's notes (raw text, OCR output, or Word documents), categorizes each item under the existing NOTES_DB structure, creates new categories/subcategories if needed, and injects the data into index.html via a Python script. Typical triggers: add notes to study app, import to web notes library, upload knowledge to index.html."
---

# Notes Uploader - 考公资料库导入器

将整理好的知识点批量导入到 index.html 中的 `NOTES_DB` 对象。

## 工作流程

### Step 1: 确定输入来源

- 用户可能直接发文字（粘贴的笔记/OCR文本），或提供 Word/PDF 文件路径
- 如果是 Word 文件（.docx），用 `scripts/read_docx.py` 读取内容
- 如果是纯文本，直接解析

### Step 2: 清洗与分类

对每条知识点：

1. **清洗**：去除OCR错误、页眉页脚干扰（如"姓名轩"、"班级"等）、无用字、标点规范化
2. **分类**：匹配 NOTES_DB 现有分类体系

当前分类结构（8大分类，每个分类下有子分类）：

```
NOTES_DB = {
  "政治": { "时政热点", "中共党史", "政治理论", "党建纪律", "革命人物" },
  "经济": { "宏观经济", "财政税收", "金融货币", "国际贸易" },
  "法律": { "宪法", "民法", "刑法", "行政法" },
  "历史": { "中国古代史", "中国近现代史", "世界历史" },
  "人文": { "文学", "书法绘画", "戏曲艺术", "民俗文化" },
  "科技": { "航天科技", "信息技术", "生物医学", "物理化学", "前沿科技" },
  "地理": { "自然地理", "中国地理", "世界地理" },
  "申论": { "乡村振兴", "科技创新", "生态文明", "社会治理", "民生保障", "文化建设" }
}
```

3. **新分类规则**：
   - 如果知识点不属于任何现有分类，且数量≥3条，创建新的大分类
   - 如果属于某大分类但不属于任何子分类，创建新的子分类
   - 如果只有1-2条无法归类的知识点，归入最接近的现有分类，并在结果中告知用户
   - 新分类命名应简洁（2-6个字），与现有风格一致

### Step 3: 检查重复

- 对每条知识点，在 NOTES_DB 全部现有数据中搜索是否有高度相似的内容
- 去重标准：核心意思相同即视为重复（忽略表述差异）
- 跳过重复条目，在结果中告知用户跳过了多少条

### Step 4: 生成并执行注入脚本

使用 `scripts/merge_notes_db.py` 完成：

1. 读取当前 index.html
2. 解析 `const NOTES_DB={...};` 的精确范围（处理嵌套大括号）
3. 在内存中修改 JS 对象：添加新分类/子分类/条目
4. 将修改后的对象序列化回 JSON 格式，**保持与原格式一致**（每行一条子分类，每条用 `{"t":"..."} 表示`）
5. 替换 index.html 中原有的 NOTES_DB 定义
6. 验证：
   - 文件中 `const NOTES_DB=` 存在且唯一
   - `function render` 仍在文件中（未破坏V7代码）
   - 文件末尾完整（script/body/html 结束标签存在）
   - 统计总条数

### Step 5: 报告结果

向用户报告：
- 导入了多少条新知识点
- 跳过了多少条重复
- 创建了哪些新分类（如有）
- NOTES_DB 总条数更新为 X 条
- 如果文件超过 80KB，**不要用 deliver_attachments 发送**，告知用户文件已更新，用 preview_url 本地预览即可

## 重要约束

- **绝不能使用 replace_in_file 直接替换 NOTES_DB**（大文本替换容易出错）
- **必须使用 scripts/merge_notes_db.py 脚本**（确定性、可靠）
- **绝不能覆盖整个 index.html**
- **绝不能修改 NOTES_DB 以外的任何代码**
- 如果 NOTES_DB 数据太大（文件超过 150KB），建议将数据拆分到单独的 .js 文件，通过 script 标签引入
- 修改完成后必须验证 V7 核心函数完整性

## 读取 Word 文件

如果用户提供 .docx 文件，执行：

```bash
python -X utf8 scripts/read_docx.py 文件路径.docx
```

该脚本输出纯文本，每行一条知识点（段落）。

## 已有分类参考

如果不确定某条知识点该归入哪个分类，参考以下原则：

- 政治/法律/历史/申论 → 公务员考试行测常识判断常见模块
- 科技/地理 → 科技常识+地理常识
- 人文 → 文学艺术传统文化
- 公文管理/管理常识 → 归入"政治"下新建子分类
- 经济/金融 → 归入"经济"相关子分类
- 医学急救/生活常识 → 归入"科技"→"生物医学"或新建子分类
