"""
merge_notes_db.py - Safely merge new knowledge items into index.html's NOTES_DB.

Usage:
  python merge_notes_db.py index.html --add '{"分类":{"子分类":[{"t":"知识点"}]}}'
  python merge_notes_db.py index.html --json additions.json

The additions JSON format must match NOTES_DB structure:
{
  "分类名": {
    "子分类名": [{"t": "知识点文本"}]
  }
}

Steps:
1. Read index.html
2. Find const NOTES_DB={...}; (handle nested braces)
3. Parse existing DB
4. Merge additions (dedup by core meaning)
5. Serialize back maintaining original format
6. Replace in index.html
7. Validate integrity
"""
import sys
import json
import re
import os

def find_notes_db_range(html):
    """Find the start and end positions of const NOTES_DB={...};"""
    start_marker = 'const NOTES_DB='
    start_idx = html.find(start_marker)
    if start_idx == -1:
        return None, None
    
    # Find the opening brace
    brace_start = html.index('{', start_idx)
    # Track nested braces to find matching close
    depth = 0
    for i in range(brace_start, len(html)):
        if html[i] == '{':
            depth += 1
        elif html[i] == '}':
            depth -= 1
            if depth == 0:
                # Find the semicolon after closing brace
                end_idx = i + 1
                while end_idx < len(html) and html[end_idx] in ' \t\n':
                    end_idx += 1
                if end_idx < len(html) and html[end_idx] == ';':
                    end_idx += 1
                return start_idx, end_idx
    
    return None, None


def serialize_db(db):
    """Serialize NOTES_DB to match the original format (compact JSON on few lines)."""
    # Use compact format for sub-arrays, readable format for structure
    parts = []
    for cat_name, subcats in db.items():
        sub_parts = []
        for sub_name, items in subcats.items():
            items_str = ','.join(json.dumps({"t": item["t"]}, ensure_ascii=False) for item in items)
            sub_parts.append(f'"{sub_name}":[{items_str}]')
        parts.append(f'"{cat_name}":{{{",".join(sub_parts)}}}')
    return 'const NOTES_DB={' + ','.join(parts) + '};'


def normalize_text(text):
    """Normalize text for dedup comparison."""
    # Remove all punctuation and whitespace, lowercase
    return re.sub(r'[\s，。、；：""''（）【】《》！？\.,;:\(\)\[\]\{\}\-\—\u3000]', '', text)


def is_duplicate(new_text, existing_texts, threshold=0.8):
    """Check if new_text is a duplicate of any existing text."""
    norm_new = normalize_text(new_text)
    if not norm_new:
        return False
    for existing in existing_texts:
        norm_existing = normalize_text(existing)
        if not norm_existing:
            continue
        # Check if one contains the other (for shortened/extended versions)
        if norm_new == norm_existing:
            return True
        len_short = min(len(norm_new), len(norm_existing))
        len_long = max(len(norm_new), len(norm_existing))
        if len_short / len_long < threshold:
            continue
        # Check character overlap
        common = sum(1 for c in norm_new if c in norm_existing)
        if common / len(norm_new) > threshold and common / len(norm_existing) > threshold:
            return True
    return False


def get_all_texts(db):
    """Get all existing text items from DB."""
    texts = []
    for cat in db.values():
        for sub in cat.values():
            for item in sub:
                texts.append(item["t"])
    return texts


def main():
    if len(sys.argv) < 4 or sys.argv[2] not in ('--add', '--json'):
        print("Usage: python merge_notes_db.py <index.html> --add '<json>'")
        print("       python merge_notes_db.py <index.html> --json <additions.json>")
        sys.exit(1)
    
    html_path = sys.argv[1]
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()
    
    # Parse additions
    if sys.argv[2] == '--add':
        additions = json.loads(sys.argv[3])
    else:
        with open(sys.argv[3], 'r', encoding='utf-8') as f:
            additions = json.load(f)
    
    # Find NOTES_DB
    start, end = find_notes_db_range(html)
    if start is None:
        print("ERROR: Cannot find const NOTES_DB= in index.html")
        sys.exit(1)
    
    # Parse existing DB
    old_db_str = html[start:end]
    # Extract the JSON part (after '=' and before ';')
    json_start = old_db_str.index('{')
    json_end = old_db_str.rindex('}') + 1
    db_json = old_db_str[json_start:json_end]
    
    try:
        db = json.loads(db_json)
    except json.JSONDecodeError as e:
        print(f"ERROR: Failed to parse NOTES_DB JSON: {e}")
        sys.exit(1)
    
    # Get all existing texts for dedup
    all_texts = get_all_texts(db)
    
    # Merge additions
    total_added = 0
    total_dup = 0
    new_cats = []
    new_subs = []
    
    for cat_name, subcats in additions.items():
        if cat_name not in db:
            db[cat_name] = {}
            new_cats.append(cat_name)
        
        for sub_name, items in subcats.items():
            if sub_name not in db[cat_name]:
                db[cat_name][sub_name] = []
                new_subs.append(f"{cat_name}/{sub_name}")
            
            for item in items:
                text = item["t"] if isinstance(item, dict) else str(item)
                if is_duplicate(text, all_texts):
                    total_dup += 1
                else:
                    db[cat_name][sub_name].append({"t": text})
                    all_texts.append(text)
                    total_added += 1
    
    # Serialize and replace
    new_db_str = serialize_db(db)
    new_html = html[:start] + new_db_str + html[end:]
    
    # Validate
    checks = {
        "const NOTES_DB=": "const NOTES_DB=" in new_html,
        "function render": "function render" in new_html,
        "</script>": "</script>" in new_html,
        "</body></html>": "</body></html>" in new_html,
    }
    
    # Count total items
    total_items = len(get_all_texts(db))
    
    # Write
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(new_html)
    
    print(f"SUCCESS: Merged {total_added} items, skipped {total_dup} duplicates")
    print(f"Total items in NOTES_DB: {total_items}")
    if new_cats:
        print(f"New categories created: {', '.join(new_cats)}")
    if new_subs:
        print(f"New subcategories created: {', '.join(new_subs)}")
    print(f"File size: {len(new_html)} bytes")
    
    failed = [k for k, v in checks.items() if not v]
    if failed:
        print(f"WARNING: Integrity checks failed: {failed}")
    else:
        print("All integrity checks passed")


if __name__ == '__main__':
    main()
