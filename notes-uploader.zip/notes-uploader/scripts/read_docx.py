"""Read paragraphs from a .docx file and output as plain text (one per line)."""
import sys
try:
    from docx import Document
except ImportError:
    print("ERROR: python-docx not installed. Run: pip install python-docx")
    sys.exit(1)

def read_docx(path):
    doc = Document(path)
    lines = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            lines.append(text)
    return lines

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: python read_docx.py <file.docx>")
        sys.exit(1)
    path = sys.argv[1]
    lines = read_docx(path)
    for line in lines:
        print(line)
    print(f"\n--- Total: {len(lines)} paragraphs ---")
