# Chart Recipes — Ready-to-Use Code Templates

Quick copy-paste templates for the most common chart types using **Plotly** (interactive HTML).

---

## 1. Bar Chart (柱状图)

```python
import plotly.graph_objects as go
import pandas as pd

df = pd.DataFrame({"category": ["A", "B", "C", "D"], "value": [42, 78, 55, 91]})

fig = go.Figure(go.Bar(
    x=df["category"], y=df["value"],
    marker_color=["#2C5F8A", "#4A90D9", "#7BB8F0", "#F0A500"],
    text=df["value"], textposition="outside",
))
fig.update_layout(title="Category Comparison", plot_bgcolor="white",
                  font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("bar_chart.html", include_plotlyjs="cdn")
```

---

## 2. Line Chart (折线图)

```python
import plotly.graph_objects as go

fig = go.Figure()
fig.add_trace(go.Scatter(x=dates, y=values, mode="lines+markers",
    line=dict(color="#2C5F8A", width=2.5), marker=dict(size=7), name="Series 1"))
fig.update_layout(title="Trend Over Time", plot_bgcolor="white",
                  font=dict(family="Microsoft YaHei, SimHei, sans-serif"),
                  xaxis=dict(showgrid=False), yaxis=dict(gridcolor="#e8e8e8"))
fig.write_html("line_chart.html", include_plotlyjs="cdn")
```

---

## 3. Pie / Donut Chart (饼图/环形图)

```python
import plotly.graph_objects as go

fig = go.Figure(go.Pie(
    labels=["部分A", "部分B", "部分C", "部分D"],
    values=[35, 25, 20, 20],
    hole=0.4,   # 0 = pie, 0.3-0.5 = donut
    marker_colors=["#2C5F8A", "#4A90D9", "#F0A500", "#E05C2A"],
    textinfo="label+percent",
))
fig.update_layout(title="比例分布", font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("pie_chart.html", include_plotlyjs="cdn")
```

---

## 4. Scatter Plot (散点图)

```python
import plotly.express as px
import pandas as pd

fig = px.scatter(df, x="x_col", y="y_col", color="category_col",
                 size="size_col",   # optional bubble size
                 hover_name="label_col",
                 title="Correlation Analysis",
                 color_discrete_sequence=["#2C5F8A", "#F0A500", "#E05C2A"])
fig.update_layout(font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("scatter.html", include_plotlyjs="cdn")
```

---

## 5. Heatmap / Correlation Matrix (热力图/相关矩阵)

```python
import plotly.graph_objects as go
import pandas as pd

corr = df.select_dtypes("number").corr()
fig = go.Figure(go.Heatmap(
    z=corr.values, x=corr.columns, y=corr.index,
    colorscale="RdBu", zmin=-1, zmax=1,
    text=corr.round(2).values, texttemplate="%{text}",
))
fig.update_layout(title="Correlation Matrix",
                  font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("heatmap.html", include_plotlyjs="cdn")
```

---

## 6. Radar Chart (雷达图)

```python
import plotly.graph_objects as go

categories = ["速度", "耐力", "力量", "灵活", "协调"]
fig = go.Figure()
fig.add_trace(go.Scatterpolar(
    r=[85, 70, 90, 60, 75] + [85],   # close the polygon
    theta=categories + [categories[0]],
    fill="toself", name="运动员A",
    line_color="#2C5F8A",
))
fig.add_trace(go.Scatterpolar(
    r=[60, 85, 55, 90, 80] + [60],
    theta=categories + [categories[0]],
    fill="toself", name="运动员B",
    line_color="#F0A500",
))
fig.update_layout(polar=dict(radialaxis=dict(visible=True)),
                  title="多维度对比", font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("radar.html", include_plotlyjs="cdn")
```

---

## 7. Multi-chart Dashboard (多图仪表盘)

```python
from plotly.subplots import make_subplots
import plotly.graph_objects as go

fig = make_subplots(
    rows=2, cols=2,
    subplot_titles=["销售趋势", "产品占比", "地区对比", "相关性分析"],
    specs=[[{"type": "scatter"}, {"type": "pie"}],
           [{"type": "bar"},    {"type": "heatmap"}]],
)

# Row 1 Col 1: Line
fig.add_trace(go.Scatter(x=dates, y=sales, mode="lines+markers",
    line=dict(color="#2C5F8A")), row=1, col=1)

# Row 1 Col 2: Pie
fig.add_trace(go.Pie(labels=products, values=shares, hole=0.4), row=1, col=2)

# Row 2 Col 1: Bar
fig.add_trace(go.Bar(x=regions, y=revenues, marker_color="#4A90D9"), row=2, col=1)

# Row 2 Col 2: Heatmap
fig.add_trace(go.Heatmap(z=corr.values, x=corr.columns, y=corr.index,
    colorscale="RdBu"), row=2, col=2)

fig.update_layout(height=800, title_text="业务综合仪表盘",
                  showlegend=False,
                  font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("dashboard.html", include_plotlyjs="cdn")
```

---

## 8. Funnel Chart (漏斗图)

```python
import plotly.graph_objects as go

fig = go.Figure(go.Funnel(
    y=["曝光", "点击", "加购", "下单", "支付"],
    x=[10000, 3500, 1200, 600, 420],
    textinfo="value+percent initial",
    marker_color=["#2C5F8A", "#4A90D9", "#7BB8F0", "#F0A500", "#E05C2A"],
))
fig.update_layout(title="转化漏斗", font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("funnel.html", include_plotlyjs="cdn")
```

---

## 9. Histogram (直方图)

```python
import plotly.express as px

fig = px.histogram(df, x="value_col", nbins=30, color="category_col",
                   title="Distribution",
                   color_discrete_sequence=["#2C5F8A", "#F0A500"])
fig.update_layout(bargap=0.05, plot_bgcolor="white",
                  font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("histogram.html", include_plotlyjs="cdn")
```

---

## 10. Gantt / Timeline (甘特图)

```python
import plotly.express as px
import pandas as pd

df = pd.DataFrame([
    dict(Task="任务A", Start="2026-01-01", Finish="2026-02-15", Resource="团队1"),
    dict(Task="任务B", Start="2026-02-01", Finish="2026-03-30", Resource="团队2"),
    dict(Task="任务C", Start="2026-03-15", Finish="2026-05-01", Resource="团队1"),
])
fig = px.timeline(df, x_start="Start", x_end="Finish", y="Task", color="Resource",
                  title="项目计划甘特图")
fig.update_yaxes(autorange="reversed")
fig.update_layout(font=dict(family="Microsoft YaHei, SimHei, sans-serif"))
fig.write_html("gantt.html", include_plotlyjs="cdn")
```

---

## Tips

- `include_plotlyjs="cdn"` → smaller file, requires internet
- `include_plotlyjs=True` → larger file, works fully offline
- Always set `font=dict(family="Microsoft YaHei, SimHei, sans-serif")` for Chinese support
- Chinese stock convention: **Red = 涨 (up)**, **Green = 跌 (down)**
