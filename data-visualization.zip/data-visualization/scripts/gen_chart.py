#!/usr/bin/env python3
"""
gen_chart.py - Quick chart generator for data-visualization skill
Usage:
  python gen_chart.py --type bar --data data.csv --output chart.html --title "My Chart"
  python gen_chart.py --type line --data data.csv --output chart.html --x date --y value
"""

import argparse
import json
import sys
import os

def try_import(pkg):
    try:
        return __import__(pkg)
    except ImportError:
        os.system(f"{sys.executable} -m pip install {pkg} -q")
        return __import__(pkg)

pd = try_import("pandas")
plotly = try_import("plotly")
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


# ── Color palettes ──────────────────────────────────────────────────────────
PALETTES = {
    "business": ["#2C5F8A", "#4A90D9", "#7BB8F0", "#F0A500", "#E05C2A", "#6B8E6B"],
    "vivid":    ["#E74C3C", "#3498DB", "#2ECC71", "#F39C12", "#9B59B6", "#1ABC9C"],
    "pastel":   ["#FFB3BA", "#FFDFBA", "#FFFFBA", "#BAFFC9", "#BAE1FF", "#E8BAFF"],
    "finance":  ["#C0392B", "#27AE60", "#2980B9", "#8E44AD", "#F39C12", "#7F8C8D"],
}

DEFAULT_PALETTE = PALETTES["business"]


def load_data(path: str) -> "pd.DataFrame":
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        df = pd.read_csv(path, encoding="utf-8-sig")
    elif ext in (".xlsx", ".xls"):
        df = pd.read_excel(path)
    elif ext == ".json":
        df = pd.read_json(path)
    else:
        raise ValueError(f"Unsupported file type: {ext}")
    return df


def auto_detect_xy(df: "pd.DataFrame"):
    """Guess x (first string/datetime col) and y (first numeric col)."""
    x_col = None
    y_cols = []
    for col in df.columns:
        if df[col].dtype == object or str(df[col].dtype).startswith("datetime"):
            if x_col is None:
                x_col = col
        else:
            y_cols.append(col)
    if x_col is None:
        x_col = df.columns[0]
    if not y_cols:
        y_cols = [df.columns[-1]]
    return x_col, y_cols


def build_bar(df, x, y_cols, title, palette):
    fig = go.Figure()
    for i, y in enumerate(y_cols):
        fig.add_trace(go.Bar(
            x=df[x], y=df[y], name=y,
            marker_color=palette[i % len(palette)],
            text=df[y], textposition="outside",
        ))
    fig.update_layout(
        title=title, barmode="group",
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
        xaxis=dict(showgrid=False),
        yaxis=dict(gridcolor="#e8e8e8"),
        legend=dict(orientation="h", y=-0.15),
    )
    return fig


def build_line(df, x, y_cols, title, palette):
    fig = go.Figure()
    for i, y in enumerate(y_cols):
        fig.add_trace(go.Scatter(
            x=df[x], y=df[y], name=y,
            mode="lines+markers",
            line=dict(color=palette[i % len(palette)], width=2.5),
            marker=dict(size=7),
        ))
    fig.update_layout(
        title=title,
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
        xaxis=dict(showgrid=False),
        yaxis=dict(gridcolor="#e8e8e8"),
        legend=dict(orientation="h", y=-0.15),
    )
    return fig


def build_pie(df, x, y_cols, title, palette):
    y = y_cols[0]
    fig = go.Figure(go.Pie(
        labels=df[x], values=df[y],
        marker_colors=palette,
        textinfo="label+percent",
        hole=0.35,
    ))
    fig.update_layout(
        title=title,
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
        legend=dict(orientation="v"),
    )
    return fig


def build_scatter(df, x, y_cols, title, palette):
    y = y_cols[0]
    fig = go.Figure(go.Scatter(
        x=df[x], y=df[y],
        mode="markers",
        marker=dict(color=palette[0], size=9, opacity=0.75),
    ))
    fig.update_layout(
        title=title,
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
        xaxis=dict(gridcolor="#e8e8e8"),
        yaxis=dict(gridcolor="#e8e8e8"),
    )
    return fig


def build_heatmap(df, title, palette):
    numeric = df.select_dtypes("number")
    corr = numeric.corr()
    fig = go.Figure(go.Heatmap(
        z=corr.values,
        x=corr.columns.tolist(),
        y=corr.index.tolist(),
        colorscale="RdBu",
        zmin=-1, zmax=1,
        text=corr.round(2).values,
        texttemplate="%{text}",
    ))
    fig.update_layout(
        title=title or "Correlation Heatmap",
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=12),
    )
    return fig


def build_radar(df, x, y_cols, title, palette):
    categories = df[x].tolist()
    fig = go.Figure()
    for i, y in enumerate(y_cols):
        vals = df[y].tolist()
        vals.append(vals[0])  # close the polygon
        fig.add_trace(go.Scatterpolar(
            r=vals,
            theta=categories + [categories[0]],
            name=y,
            fill="toself",
            line_color=palette[i % len(palette)],
        ))
    fig.update_layout(
        polar=dict(radialaxis=dict(visible=True, showgrid=True)),
        title=title,
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
    )
    return fig


def build_combo(df, x, y_cols, title, palette):
    """Bar for first y, line for the rest."""
    fig = make_subplots(specs=[[{"secondary_y": len(y_cols) > 1}]])
    fig.add_trace(go.Bar(
        x=df[x], y=df[y_cols[0]], name=y_cols[0],
        marker_color=palette[0], opacity=0.75,
    ), secondary_y=False)
    for i, y in enumerate(y_cols[1:], 1):
        fig.add_trace(go.Scatter(
            x=df[x], y=df[y], name=y, mode="lines+markers",
            line=dict(color=palette[i % len(palette)], width=2.5),
        ), secondary_y=True)
    fig.update_layout(
        title=title,
        plot_bgcolor="white", paper_bgcolor="white",
        font=dict(family="Microsoft YaHei, SimHei, sans-serif", size=13),
        legend=dict(orientation="h", y=-0.15),
    )
    return fig


BUILDERS = {
    "bar":      build_bar,
    "line":     build_line,
    "pie":      build_pie,
    "scatter":  build_scatter,
    "heatmap":  build_heatmap,
    "radar":    build_radar,
    "combo":    build_combo,
}


def main():
    parser = argparse.ArgumentParser(description="Quick chart generator")
    parser.add_argument("--type",   default="bar",  choices=list(BUILDERS), help="Chart type")
    parser.add_argument("--data",   required=True,   help="Path to CSV/Excel/JSON data file")
    parser.add_argument("--output", default="chart.html", help="Output HTML file path")
    parser.add_argument("--title",  default="",     help="Chart title")
    parser.add_argument("--x",      default=None,   help="Column name for x-axis / labels")
    parser.add_argument("--y",      default=None,   nargs="+", help="Column name(s) for y-axis / values")
    parser.add_argument("--palette",default="business", choices=list(PALETTES), help="Color palette")
    args = parser.parse_args()

    df = load_data(args.data)
    palette = PALETTES[args.palette]

    x_col, y_cols = auto_detect_xy(df)
    if args.x:
        x_col = args.x
    if args.y:
        y_cols = args.y

    chart_type = args.type
    title = args.title or f"{chart_type.capitalize()} Chart"

    if chart_type == "heatmap":
        fig = build_heatmap(df, title, palette)
    elif chart_type == "pie":
        fig = build_pie(df, x_col, y_cols, title, palette)
    elif chart_type == "scatter":
        fig = build_scatter(df, x_col, y_cols, title, palette)
    elif chart_type == "radar":
        fig = build_radar(df, x_col, y_cols, title, palette)
    elif chart_type == "combo":
        fig = build_combo(df, x_col, y_cols, title, palette)
    elif chart_type == "line":
        fig = build_line(df, x_col, y_cols, title, palette)
    else:
        fig = build_bar(df, x_col, y_cols, title, palette)

    fig.write_html(args.output, include_plotlyjs="cdn")
    print(f"Chart saved to: {os.path.abspath(args.output)}")


if __name__ == "__main__":
    main()
