---
name: data-visualization
description: "This skill should be used whenever the user wants to visualize data, create charts, generate dashboards, or turn raw numbers/tables/CSVs into visual outputs. Typical triggers: '帮我画图', '生成图表', '可视化这些数据', '做一个仪表盘', 'plot this', 'visualize', 'show me a chart', 'bar chart', 'pie chart', 'line chart', 'heatmap', 'scatter plot'. Also use when the user pastes a table or CSV and wants it rendered visually."
---

# Data Visualization Skill

## Purpose

Transform raw data (tables, CSV, JSON, user-described numbers) into clear, visually rich outputs. Supports static charts (Matplotlib/Seaborn), interactive HTML dashboards (Plotly/ECharts), and styled HTML reports.

## When to Use

- User provides data (CSV, Excel, JSON, a pasted table, or described numbers) and wants a chart
- User says "帮我画图", "可视化", "生成图表", "做仪表盘", "plot", "visualize", "show me a chart"
- User asks for bar, line, pie, scatter, heatmap, radar, funnel, sankey, or any other chart type
- User wants a full HTML dashboard combining multiple charts

## Output Formats

| Format | When to Use | Library |
|--------|-------------|---------|
| PNG/SVG image | Static charts for documents or sharing | Matplotlib / Seaborn |
| Interactive HTML | Dashboards, explorable charts | Plotly or ECharts |
| PDF report | Formal reports with charts + text | ReportLab + Matplotlib |

**Default**: Generate an **interactive HTML file** with Plotly or ECharts unless the user specifies otherwise. Interactive charts are always more impressive and useful.

## Workflow

### Step 1 — Understand the Data and Goal

Before writing any code, determine:
1. **Data source**: pasted table / CSV file / Excel / described numbers / database?
2. **Chart type**: bar / line / pie / scatter / heatmap / combo / dashboard?
3. **Key message**: what insight should the chart communicate?
4. **Output format**: image / interactive HTML / PDF?

If the data source is a file, read it first. If the chart type is unclear, choose the most suitable one based on the data shape (time series → line, categories → bar, proportions → pie, correlation → scatter).

### Step 2 — Prepare the Data

- Parse CSV/Excel using pandas
- Clean missing values (fill with 0 or drop depending on context)
- Aggregate if needed (group by date, category, etc.)
- For Chinese labels: ensure UTF-8 encoding and proper font handling

### Step 3 — Generate the Visualization

**For interactive HTML (preferred)**, use the `scripts/gen_chart.py` helper:

```bash
python scripts/gen_chart.py --type <chart_type> --data <data.csv> --output <output.html> --title "Chart Title"
```

Supported `--type` values: `bar`, `line`, `pie`, `scatter`, `heatmap`, `radar`, `combo`

**For custom charts**, write Plotly/ECharts code directly. Reference `references/chart_recipes.md` for ready-to-use templates for common chart types.

**Chinese font support** (Matplotlib): always set `plt.rcParams['font.family'] = ['SimHei', 'Microsoft YaHei', 'sans-serif']` and `plt.rcParams['axes.unicode_minus'] = False`.

### Step 4 — Polish the Output

Apply these defaults for professional-looking results:
- **Color palette**: Use `assets/color_palettes.json` for consistent brand-friendly colors
- **Title**: Always include a clear, descriptive chart title
- **Labels**: Show data labels on bars/pies when there are ≤ 12 data points
- **Legend**: Include when there are multiple series
- **Grid**: Light gray grid lines for readability
- **Chinese stock convention**: Red = price increase (涨), Green = price decrease (跌)

### Step 5 — Deliver

- Save HTML to the workspace and call `preview_url` to display in browser
- Save PNG/SVG using `plt.savefig()` with `dpi=150, bbox_inches='tight'`
- Use `open_result_view` for image/PDF outputs
- Mention the saved file path in the reply

## Common Patterns

### Pasted Table → Bar Chart
User pastes data in chat → parse as pandas DataFrame from string → generate bar chart HTML → preview.

### CSV File → Dashboard
Read CSV → auto-detect columns → generate 2-4 charts in a single HTML page using Plotly subplots → preview.

### "帮我画一个折线图，数据是..." 
Parse numbers from natural language → create DataFrame → line chart → preview.

## Dependencies

Ensure these are available before running scripts:
```
pip install pandas plotly matplotlib seaborn openpyxl
```

If a package is missing, install it silently with `pip install <package>` before proceeding.

## References

- `references/chart_recipes.md` — Ready-to-use code templates for 10+ chart types
- `references/echarts_guide.md` — ECharts JSON config patterns for pure-HTML charts (no Python needed)

## Assets

- `assets/color_palettes.json` — Curated color schemes (business, vivid, pastel, finance)
