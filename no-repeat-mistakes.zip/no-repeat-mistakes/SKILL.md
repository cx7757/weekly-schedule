---
name: no-repeat-mistakes
description: "This skill should be used whenever about to attempt an operation that has failed before, when the user expresses frustration about repeated errors, when starting a task similar to one that had issues previously, or at the start of any session to review known pitfalls. It maintains a living catalog of past mistakes and their solutions to prevent recurrence. Also trigger when a product/project iteration is complete and needs a retrospective review."
---

# No-Repeat-Mistakes — 任务失败回溯与防重蹈覆辙机制

## 技能目标

在执行高风险操作前**自动快照**当前状态，任务失败时**一键回滚**到最近可用版本，并将失败原因和修复方案记录到持久化错误日志，防止同类问题再次发生。

---

## 核心工作流

### Phase 0：查历史，避已知坑

**每次接到新任务时**，先读取错误日志：

```
~/.workbuddy/skills/no-repeat-mistakes/assets/mistakes_catalog.json
```

检索是否存在相同或相似的失败记录。如果有，**先告知用户历史教训**，再继续执行。

### Phase 1：执行前快照

在执行任何可能失败或破坏文件的操作前，调用快照脚本：

```bash
python ~/.workbuddy/skills/no-repeat-mistakes/scripts/snapshot.py snapshot \
  --target <目标目录或文件> \
  --label "<任务描述简称>"
```

- 快照保存在 `~/.workbuddy/skills/no-repeat-mistakes/assets/snapshots/`
- 每个快照包含：时间戳、标签、文件内容（文本）或 zip 压缩包（目录）
- 最多保留最近 **20 个快照**，超出自动删除最旧的

### Phase 2：执行任务

正常执行用户请求。期间监控以下失败信号：
- 工具返回错误、异常退出
- 文件损坏/内容丢失
- 用户明确说"不对"、"回滚"、"恢复之前"、"回到上个版本"

### Phase 3：失败时立即回滚

检测到失败时，**不要继续修复**，先回滚：

```bash
python ~/.workbuddy/skills/no-repeat-mistakes/scripts/snapshot.py restore \
  --snapshot-id <快照ID>
```

回滚后告知用户：
- 已恢复到哪个版本（时间戳 + 标签）
- 失败的原因（简要分析）
- 建议的下一步修复思路（不要贸然再执行）

### Phase 4：记录失败，沉淀经验

回滚完成后，将本次失败信息追加到错误日志：

```bash
python ~/.workbuddy/skills/no-repeat-mistakes/scripts/snapshot.py log-mistake \
  --task "<任务描述>" \
  --error "<错误信息摘要>" \
  --fix "<正确做法/避坑方案>" \
  --file "<涉及的文件路径（可选）>"
```

---

## 常见触发场景

| 用户说了什么 | 对应动作 |
|-------------|---------|
| "回到之前可用的版本" | Phase 3 立即回滚 |
| "这个版本不行" | Phase 3 回滚 + Phase 4 记录 |
| "恢复上一个版本" | Phase 3 立即回滚 |
| "帮我做X（高风险操作）" | Phase 0 查历史 + Phase 1 先快照 |
| "之前好像做过类似的，失败了" | Phase 0 查历史日志 |
| "这次迭代完成了，做个回顾" | Phase 4 记录本次教训 |

---

## 快照列表查询

```bash
python ~/.workbuddy/skills/no-repeat-mistakes/scripts/snapshot.py list
```

输出格式：
```
ID   时间                  标签                  大小
001  2026-04-17 10:30:00   index.html合并前       245KB
002  2026-04-17 11:00:00   gen_notes.py修改前     12KB
```

---

## 注意事项

- 快照只保留**文本文件**和**小型目录**（<50MB），超大二进制文件不快照
- 如果目标是 git 仓库，优先用 `git stash` / `git checkout` 代替快照脚本
- 同一任务不要创建超过 3 个快照，避免混乱
- 错误日志是持久记忆，**不要删除**，它是防止重蹈覆辙的核心

---

## 参考资料

参见 `references/rollback_guide.md`，包含：
- 常见文件回滚场景详解
- git 回滚命令速查
- 快照脚本完整参数说明
