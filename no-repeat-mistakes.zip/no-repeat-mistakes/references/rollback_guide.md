# 回滚操作指南

## 1. 使用 snapshot.py 回滚（推荐用于单文件/小目录）

### 快速流程

```
# 执行前先快照
python snapshot.py snapshot --target ./index.html --label "合并notes库之前"

# 任务失败，查看快照列表
python snapshot.py list

# 回滚到指定快照
python snapshot.py restore --snapshot-id 001
```

### 适用场景
- 单个 HTML/Python/JSON 文件的修改前备份
- 小型项目目录（<50MB）的整体备份
- 不在 git 管理范围内的文件

---

## 2. 使用 Git 回滚（推荐用于 git 仓库）

### 查看历史
```bash
git log --oneline -10
```

### 回滚到上一个 commit（保留工作区修改）
```bash
git reset HEAD~1
```

### 回滚到指定 commit（丢弃后续所有修改）
```bash
git reset --hard <commit-hash>
```

### 只回滚某个文件
```bash
git checkout <commit-hash> -- path/to/file
```

### 暂存当前工作（不丢弃）
```bash
git stash
# 恢复
git stash pop
```

---

## 3. 常见失败场景与回滚策略

| 场景 | 推荐方案 |
|------|---------|
| 合并代码到 index.html 后页面白屏 | snapshot restore 或 git checkout |
| Python 脚本修改后运行报错 | snapshot restore（单文件） |
| 整个项目目录被误改 | snapshot restore（dir_zip） |
| 大文件（>50MB）出错 | git reset --hard |
| 记不清改了哪里 | git diff 查看变更 |

---

## 4. snapshot.py 完整参数说明

### snapshot（创建快照）
```
--target   要快照的路径（文件或目录）
--label    标签（描述这次快照的目的，如"合并前"）
```

### restore（回滚）
```
--snapshot-id   快照ID（从 list 命令获取）
```

### list（查看所有快照）
无参数，直接列出所有快照的ID/时间/标签/大小。

### log-mistake（记录失败教训）
```
--task    任务描述
--error   错误信息摘要
--fix     正确做法或避坑方案
--file    涉及的文件路径（可选）
```

### show-mistakes（查看历史教训）
```
--keyword   按关键词过滤（可选）
```

---

## 5. 注意事项

- 快照上限：20个，超出自动删除最旧的
- 单次快照大小限制：50MB（超出时会提示用 git）
- 快照存储位置：`~/.workbuddy/skills/no-repeat-mistakes/assets/snapshots/`
- 错误日志位置：`~/.workbuddy/skills/no-repeat-mistakes/assets/mistakes_catalog.json`
