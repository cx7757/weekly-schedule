# Product Retrospectives

Living catalog of lessons learned from each product iteration.

Format per product:
- **Wins**: What worked well and should be repeated
- **Issues**: What went wrong and how to avoid
- **Action Items**: Specific things to keep doing, stop doing, and start doing

Search by product name or tags before starting similar work.

---

## 周计划PWA

### Iteration 8 (2026-04-12) — 产品介绍文案

**Goal**: 撰写周计划PWA的产品介绍文案，讲述8次迭代故事

#### ✅ Wins (做得好的)
- 先读取现有代码/文档，了解产品现状再动笔
- 用叙事风格描述迭代过程，而非纯功能列表
- 按版本分段讲述，逻辑清晰有层次
- 包含功能一览表、学习心得等增值内容

#### ❌ Issues (遇到的问题)
- 一开始没有明确问用户想要什么风格的文案
- 文案篇幅较长，可能需要精简版本

#### 🎯 Action Items (行动项)
- **[Keep doing]**: 先了解产品再做总结，有事实支撑的文案更有说服力
- **[Start doing]**: 写文案前先问用户风格偏好（精简/详细/营销风）
- **[Stop doing]**: 不要假设用户偏好，明确沟通需求

**Tags**: 周计划PWA, copywriting, documentation

---

### Iteration 1-7 (2026-03~04) — PWA开发迭代

**Goal**: 开发一个周计划PWA应用，涵盖课程表、打卡、艾森豪威尔矩阵等功能

#### ✅ Wins (做得好的)
- MVP思维：先跑起来再迭代，不追求一步到位
- 单HTML文件架构：轻量、简单、易维护
- 持续打磨：7次迭代持续优化，每次都有明确改进点
- PWA离线支持：提升用户体验
- GitHub Pages部署：方便分享和访问

#### ❌ Issues (遇到的问题)
- 早期版本没有考虑文件体积上限，导致HTML膨胀到91KB
- 模态框集成方式选择不当，与原有样式冲突
- 反复在同一文件上修改导致累积错误
- 没有提前告知用户localStorage数据与域名绑定

#### 🎯 Action Items (行动项)
- **[Keep doing]**: MVP优先，先验证需求再做完美
- **[Keep doing]**: 每次迭代有明确目标，不盲目堆功能
- **[Stop doing]**: 避免在单个文件上反复修改，先分析结构再动手
- **[Start doing]**: 集成大量内容时考虑独立页面，保持主文件轻量
- **[Start doing]**: 修改涉及数据存储的文件前，先导出备份

**Tags**: 周计划PWA, PWA, HTML, iterative-development

---

## [Add new products here]

When starting a new product/project, add a new section above this line.

