# Known Errors Catalog

A living document of past mistakes, their causes, and prevention strategies.
Search by tags before attempting similar tasks.

---

### 考公资料嵌入模态框导致体积膨胀和回退困难
- **Date**: 2026-04-12
- **Context**: 周计划PWA V8版本，将考公资料以模态框形式嵌入index.html
- **Mistake**: 把177条考公数据全部嵌入HTML文件中，导致文件体积从~30KB膨胀到~91KB，且模态框CSS/JS与原有样式冲突
- **Root Cause**: 没有考虑单文件体积上限和样式隔离问题，选错了集成方式
- **Prevention**: 集成大量内容时优先考虑独立页面或视图切换，避免模态框；保持主文件轻量
- **Correct Approach**: 使用视图切换（显示/隐藏div）而非模态框，或者保持独立notes.html页面
- **Tags**: HTML, architecture, modal, file-size, integration, 周计划PWA

### 多次修改后预览结果不对（HTML合并冲突）
- **Date**: 2026-04-12
- **Context**: 反复修改index.html合并考公资料子页面，每次修改后用户预览仍有问题
- **Mistake**: 在不确定现有HTML标签位置的情况下进行插入，导致</style>和</script>标签错位，CSS/JS注入到错误位置
- **Root Cause**: 没有先精确定位插入点就直接修改，导致多次累积错误
- **Prevention**: 修改HTML前必须先用search精确定位目标标签位置，确认后再执行替换。避免在同一文件上反复试错
- **Correct Approach**: 先read_file或search_content找到精确的插入锚点（行号+上下文），然后用精确的old_str进行替换
- **Tags**: HTML, editing, debugging, iterative-error, 周计划PWA

### GitHub HTTPS在国内被干扰（连接重置）
- **Date**: 2026-04-12
- **Context**: 通过GitHub Pages部署周计划网页，国内用户无法访问
- **Mistake**: 假设GitHub Pages部署后立即可访问，未考虑国内网络环境
- **Root Cause**: GitHub HTTPS（443端口）在中国大陆经常被间歇性干扰，ping通但连接被重置是常态
- **Prevention**: 部署GitHub Pages后，同时提供本地HTML文件给用户。不要依赖GitHub作为唯一分发渠道
- **Correct Approach**: 推送GitHub的同时，通过deliver_attachments发送本地HTML文件作为备份方案
- **Tags**: GitHub, network, deployment, CDN, China, 周计划PWA

### GitHub Pages CDN缓存导致用户看不到新版本
- **Date**: 2026-04-12
- **Context**: 推送新版本到GitHub后，用户访问仍看到旧版本
- **Mistake**: 告诉用户"已经部署好了"但没有说明CDN缓存延迟
- **Root Cause**: GitHub Pages使用全球CDN，缓存传播需要1-5分钟
- **Prevention**: 部署后明确告知用户需要等待1-5分钟，并建议硬刷新（Ctrl+Shift+R）或用隐私窗口验证
- **Correct Approach**: 部署后等待30秒，然后提醒用户可能的缓存延迟，提供多种验证方式
- **Tags**: GitHub, Pages, CDN, cache, deployment

### localStorage数据丢失（域名/协议隔离）
- **Date**: 2026-04-12
- **Context**: 用户打开新版本HTML文件后，发现之前保存的计划数据全部消失
- **Mistake**: 未告知用户localStorage数据与域名/文件路径绑定，不同路径的数据不共享
- **Root Cause**: localStorage按origin（协议+域名+端口）隔离。file:///C:/path/index.html 和 file:///C:/path/index_new.html 是不同的origin
- **Prevention**: 任何涉及localStorage数据迁移的操作前，必须先明确告知用户数据不自动迁移，并提供导出/导入方案
- **Correct Approach**: 在V7中已经实现了数据导出导入功能，修改文件前应先导出数据，修改后再导入
- **Tags**: localStorage, data-loss, HTML, browser, 周计划PWA

### 同一错误反复尝试3次以上（无脑重试循环）
- **Date**: 2026-04-12
- **Context**: 合并HTML文件时反复修改但每次预览都不对
- **Mistake**: 在同一文件上反复修改，每次只做微小调整，没有从根本上分析问题
- **Root Cause**: 陷入"微调循环"，没有退后一步审视整体方案是否正确
- **Prevention**: 如果同一问题修改3次仍未解决，必须停下来重新分析根本原因，考虑完全不同的方案
- **Correct Approach**: 停止修改 → 从头读取完整文件 → 分析结构问题 → 制定一次性修复方案 → 验证后执行
- **Tags**: workflow, debugging, iterative-error, pattern

---

## 统计

| 类别 | 数量 |
|------|------|
| Architecture / Design | 1 |
| Technical (HTML/CSS/JS) | 2 |
| Workflow | 2 |
| Environment (Network/CDN) | 2 |

_最后更新: 2026-04-12_
