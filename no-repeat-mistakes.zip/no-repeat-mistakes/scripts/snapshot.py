#!/usr/bin/env python3
"""
snapshot.py — 任务失败回溯与快照管理工具
用法：
  python snapshot.py snapshot --target <路径> --label <标签>
  python snapshot.py restore  --snapshot-id <ID>
  python snapshot.py list
  python snapshot.py log-mistake --task <任务> --error <错误> --fix <修复> [--file <文件>]
  python snapshot.py show-mistakes [--keyword <关键词>]
"""

import argparse
import json
import os
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path

# ── 存储目录 ──────────────────────────────────────────────
SKILL_DIR = Path.home() / ".workbuddy" / "skills" / "no-repeat-mistakes" / "assets"
SNAPSHOTS_DIR = SKILL_DIR / "snapshots"
CATALOG_FILE = SKILL_DIR / "mistakes_catalog.json"
INDEX_FILE = SNAPSHOTS_DIR / "index.json"
MAX_SNAPSHOTS = 20

def ensure_dirs():
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    SKILL_DIR.mkdir(parents=True, exist_ok=True)

def load_index():
    if INDEX_FILE.exists():
        return json.loads(INDEX_FILE.read_text(encoding="utf-8"))
    return []

def save_index(index):
    INDEX_FILE.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")

def load_catalog():
    if CATALOG_FILE.exists():
        return json.loads(CATALOG_FILE.read_text(encoding="utf-8"))
    return []

def save_catalog(catalog):
    CATALOG_FILE.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")

# ── snapshot 命令 ─────────────────────────────────────────
def cmd_snapshot(target: str, label: str):
    ensure_dirs()
    target_path = Path(target).resolve()
    if not target_path.exists():
        print(f"[ERROR] 目标路径不存在：{target_path}")
        sys.exit(1)

    index = load_index()
    snap_id = str(len(index) + 1).zfill(3)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    snap_dir = SNAPSHOTS_DIR / snap_id

    # 判断大小（>50MB 不快照）
    if target_path.is_dir():
        total = sum(f.stat().st_size for f in target_path.rglob("*") if f.is_file())
    else:
        total = target_path.stat().st_size

    if total > 50 * 1024 * 1024:
        print(f"[WARN] 目标超过50MB（{total//1024//1024}MB），跳过快照。请改用 git stash。")
        sys.exit(0)

    snap_dir.mkdir(parents=True, exist_ok=True)

    if target_path.is_dir():
        zip_path = snap_dir / "content.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in target_path.rglob("*"):
                if f.is_file():
                    zf.write(f, f.relative_to(target_path.parent))
        size_str = f"{zip_path.stat().st_size // 1024}KB"
        snap_type = "dir_zip"
    else:
        dst = snap_dir / target_path.name
        shutil.copy2(target_path, dst)
        size_str = f"{dst.stat().st_size // 1024}KB"
        snap_type = "file"

    entry = {
        "id": snap_id,
        "timestamp": timestamp,
        "label": label,
        "target": str(target_path),
        "type": snap_type,
        "size": size_str,
    }
    index.append(entry)

    # 超出最大数量时删除最旧的
    if len(index) > MAX_SNAPSHOTS:
        oldest = index.pop(0)
        old_dir = SNAPSHOTS_DIR / oldest["id"]
        if old_dir.exists():
            shutil.rmtree(old_dir)
        print(f"[INFO] 已删除最旧快照：{oldest['id']} ({oldest['label']})")

    save_index(index)
    print(f"[OK] 快照已创建 → ID: {snap_id} | 时间: {timestamp} | 标签: {label} | 大小: {size_str}")
    return snap_id

# ── restore 命令 ──────────────────────────────────────────
def cmd_restore(snap_id: str):
    ensure_dirs()
    index = load_index()
    entry = next((e for e in index if e["id"] == snap_id), None)
    if not entry:
        print(f"[ERROR] 未找到快照 ID: {snap_id}")
        print("可用快照列表：")
        cmd_list()
        sys.exit(1)

    target_path = Path(entry["target"])
    snap_dir = SNAPSHOTS_DIR / snap_id

    if entry["type"] == "dir_zip":
        zip_path = snap_dir / "content.zip"
        if target_path.exists():
            shutil.rmtree(target_path)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(target_path.parent)
        print(f"[OK] 目录已恢复 → {target_path}")
    else:
        src = snap_dir / target_path.name
        shutil.copy2(src, target_path)
        print(f"[OK] 文件已恢复 → {target_path}")

    print(f"[INFO] 恢复自快照 {snap_id} | {entry['timestamp']} | 标签: {entry['label']}")

# ── list 命令 ─────────────────────────────────────────────
def cmd_list():
    ensure_dirs()
    index = load_index()
    if not index:
        print("[INFO] 暂无快照记录。")
        return
    print(f"{'ID':<5} {'时间':<22} {'标签':<30} {'大小'}")
    print("-" * 70)
    for e in index:
        print(f"{e['id']:<5} {e['timestamp']:<22} {e['label']:<30} {e.get('size','?')}")

# ── log-mistake 命令 ──────────────────────────────────────
def cmd_log_mistake(task: str, error: str, fix: str, file: str = ""):
    ensure_dirs()
    catalog = load_catalog()
    entry = {
        "id": len(catalog) + 1,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "task": task,
        "error": error,
        "fix": fix,
        "file": file,
    }
    catalog.append(entry)
    save_catalog(catalog)
    print(f"[OK] 错误记录已保存（共 {len(catalog)} 条）")

# ── show-mistakes 命令 ────────────────────────────────────
def cmd_show_mistakes(keyword: str = ""):
    ensure_dirs()
    catalog = load_catalog()
    if not catalog:
        print("[INFO] 暂无历史错误记录，保持清白！")
        return
    results = catalog
    if keyword:
        kw = keyword.lower()
        results = [e for e in catalog if kw in e["task"].lower() or kw in e["error"].lower() or kw in e.get("file","").lower()]
    if not results:
        print(f"[INFO] 未找到关键词 '{keyword}' 相关的错误记录。")
        return
    for e in results:
        print(f"\n--- 记录 #{e['id']} [{e['timestamp']}] ---")
        print(f"任务: {e['task']}")
        print(f"错误: {e['error']}")
        print(f"修复: {e['fix']}")
        if e.get("file"):
            print(f"文件: {e['file']}")

# ── 主入口 ────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="no-repeat-mistakes 快照与回溯工具")
    subparsers = parser.add_subparsers(dest="command")

    # snapshot
    p_snap = subparsers.add_parser("snapshot", help="创建快照")
    p_snap.add_argument("--target", required=True, help="要快照的文件或目录路径")
    p_snap.add_argument("--label", required=True, help="快照标签（任务描述）")

    # restore
    p_restore = subparsers.add_parser("restore", help="回滚到指定快照")
    p_restore.add_argument("--snapshot-id", required=True, help="快照ID")

    # list
    subparsers.add_parser("list", help="列出所有快照")

    # log-mistake
    p_log = subparsers.add_parser("log-mistake", help="记录一条失败教训")
    p_log.add_argument("--task", required=True, help="任务描述")
    p_log.add_argument("--error", required=True, help="错误信息摘要")
    p_log.add_argument("--fix", required=True, help="正确做法/避坑方案")
    p_log.add_argument("--file", default="", help="涉及的文件路径（可选）")

    # show-mistakes
    p_show = subparsers.add_parser("show-mistakes", help="查看历史错误记录")
    p_show.add_argument("--keyword", default="", help="按关键词过滤")

    args = parser.parse_args()

    if args.command == "snapshot":
        cmd_snapshot(args.target, args.label)
    elif args.command == "restore":
        cmd_restore(args.snapshot_id)
    elif args.command == "list":
        cmd_list()
    elif args.command == "log-mistake":
        cmd_log_mistake(args.task, args.error, args.fix, args.file)
    elif args.command == "show-mistakes":
        cmd_show_mistakes(args.keyword)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
