#!/usr/bin/env python3
"""Generate a Word document from processed knowledge items (JSON format)."""

import json
import argparse
from docx import Document
from docx.shared import Pt, Inches, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn


# Category color mapping
CATEGORY_COLORS = {
    "政治与时政": RGBColor(0xC0, 0x39, 0x2B),
    "经济常识": RGBColor(0x27, 0xAE, 0x60),
    "法律知识": RGBColor(0x29, 0x80, 0xB9),
    "历史知识": RGBColor(0x8E, 0x44, 0xAD),
    "人文与文学": RGBColor(0xD3, 0x54, 0x00),
    "科技与航天": RGBColor(0x16, 0xA0, 0x85),
    "地理知识": RGBColor(0x2C, 0x3E, 0x50),
    "生物与植物": RGBColor(0x1A, 0x5C, 0x3A),
    "医学与急救": RGBColor(0xE7, 0x4C, 0x3C),
    "化学与物理": RGBColor(0x34, 0x98, 0xDB),
    "体育常识": RGBColor(0xF3, 0x9C, 0x12),
    "文化与民俗": RGBColor(0xE6, 0x7E, 0x22),
    "其他": RGBColor(0x7F, 0x8C, 0x8D),
}

DEFAULT_COLOR = RGBColor(0x2C, 0x3E, 0x50)


def create_document(data: dict) -> Document:
    """Create a formatted Word document from knowledge data."""
    doc = Document()

    # Set default font
    style = doc.styles["Normal"]
    font = style.font
    font.name = "微软雅黑"
    font.size = Pt(11)
    style.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")

    # Title
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(data.get("title", "知识速记手册"))
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = RGBColor(0x2C, 0x3E, 0x50)
    run.font.name = "微软雅黑"
    run.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")

    # Subtitle
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run(f"共 {len(data['items'])} 条知识点 | 自动整理校对")
    run.font.size = Pt(10)
    run.font.color.rgb = RGBColor(0x95, 0xA5, 0xA6)

    doc.add_paragraph()  # spacing

    # Group by category
    categories = {}
    for item in data["items"]:
        cat = item.get("category", "其他")
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(item)

    # Sort categories by item count (descending)
    sorted_cats = sorted(categories.items(), key=lambda x: -len(x[1]))

    total_corrections = 0
    for cat_name, items in sorted_cats:
        # Category header
        header = doc.add_paragraph()
        run = header.add_run(f"【{cat_name}】（{len(items)}条）")
        run.bold = True
        run.font.size = Pt(14)
        run.font.color.rgb = CATEGORY_COLORS.get(cat_name, DEFAULT_COLOR)
        run.font.name = "微软雅黑"
        run.element.rPr.rFonts.set(qn("w:eastAsia"), "微软雅黑")

        # Items
        for i, item in enumerate(items, 1):
            # Main content
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(2)

            # Number
            num_run = p.add_run(f"{i}. ")
            num_run.bold = True
            num_run.font.size = Pt(11)

            # Content
            content_run = p.add_run(item.get("content", ""))
            content_run.font.size = Pt(11)

            # Corrections annotation (if any)
            corrections = item.get("corrections", [])
            if corrections:
                total_corrections += len(corrections)
                corr_p = doc.add_paragraph()
                corr_p.paragraph_format.space_before = Pt(0)
                corr_p.paragraph_format.space_after = Pt(2)
                corr_p.paragraph_format.left_indent = Cm(0.5)
                corr_run = corr_p.add_run(f"  修正：{'；'.join(corrections)}")
                corr_run.font.size = Pt(9)
                corr_run.font.color.rgb = RGBColor(0xE7, 0x4C, 0x3C)
                corr_run.italic = True

            # Original text (if different and provided)
            original = item.get("original", "")
            if original and original != item.get("content", ""):
                orig_p = doc.add_paragraph()
                orig_p.paragraph_format.space_before = Pt(0)
                orig_p.paragraph_format.space_after = Pt(2)
                orig_p.paragraph_format.left_indent = Cm(0.5)
                orig_run = orig_p.add_run(f"  原文：{original}")
                orig_run.font.size = Pt(9)
                orig_run.font.color.rgb = RGBColor(0x95, 0xA5, 0xA6)

            # [待核实] marker
            if item.get("unverified"):
                ver_p = doc.add_paragraph()
                ver_p.paragraph_format.space_before = Pt(0)
                ver_p.paragraph_format.left_indent = Cm(0.5)
                ver_run = ver_p.add_run("  ⚠ 待核实")
                ver_run.font.size = Pt(9)
                ver_run.font.color.rgb = RGBColor(0xF3, 0x9C, 0x12)
                ver_run.bold = True

        doc.add_paragraph()  # spacing between categories

    # Footer summary
    doc.add_paragraph()
    footer = doc.add_paragraph()
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run(f"— 共 {len(data['items'])} 条知识点，修正 {total_corrections} 处 —")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x95, 0xA5, 0xA6)
    run.italic = True

    return doc


def main():
    parser = argparse.ArgumentParser(description="Generate Word document from knowledge JSON")
    parser.add_argument("--input", "-i", help="Path to JSON input file")
    parser.add_argument("--title", "-t", default="知识速记手册", help="Document title")
    parser.add_argument("--output", "-o", default="知识速记手册.docx", help="Output docx path")
    args = parser.parse_args()

    # Read JSON
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        # Read from stdin
        data = json.loads("".join(line for line in __import__("sys").stdin))

    # Override title if specified
    if args.title != "知识速记手册":
        data["title"] = args.title

    # Create document
    doc = create_document(data)

    # Save
    doc.save(args.output)
    print(f"Done: {args.output} ({len(data['items'])} items)")


if __name__ == "__main__":
    main()
