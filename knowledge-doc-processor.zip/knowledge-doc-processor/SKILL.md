---
name: knowledge-doc-processor
description: |
  This skill should be used when the user provides raw handwritten notes, OCR text, or any unstructured knowledge material (especially exam prep content like 考公/公务员) and needs it cleaned, verified, categorized, and exported as a polished document (Word/PDF). Typical triggers: "帮我整理资料", "校对这些知识点", "生成速记手册", "查错别字", "整理笔记成文档". The skill handles OCR error correction, factual verification against real-world knowledge, intelligent categorization, and document generation with professional formatting.
---

# Knowledge Doc Processor - 知识资料整理与文档生成

## Overview

Process raw knowledge notes (handwritten OCR, typed, or voice-to-text) into clean, verified, well-categorized documents. Designed primarily for Chinese civil service exam (考公) preparation materials but applicable to any knowledge compilation task.

## Workflow

### Step 1: Receive and Parse Raw Material

1. Read the user-provided raw text (from chat, file, or image OCR).
2. Identify individual knowledge items — typically numbered list items, each containing one or more facts.
3. Split into discrete knowledge points, one per item.

### Step 2: Correct OCR/Typo Errors

For each knowledge point, apply OCR-specific error correction:

**Common OCR error patterns (Chinese):**

| Wrong Pattern | Correct | Example |
|---|---|---|
| 形近字混淆 | 修正 | 堂螂→蟑螂, 河畔→河蚌 |
| 声近字混淆 | 修正 | 甲醒→甲醛, 女变→衰变 |
| 标点异常 | 修正 | 。→、, ，→、 |
| 多余/缺失字 | 修正 | 去除无用字, 补全缺失字 |
| 数字/符号混入 | 修正 | e6→序号, (672)→去除 |
| 页眉页脚干扰 | 去除 | "姓名轩", "班级老师" |

**Specific high-frequency OCR errors for exam notes:**
- 人名：邓小平(邵小平)、张云逸(张云退)、任弼时(任弧时)
- 地名：井冈山(井岗山)、孟良崮(孟良崎)、瓜达尔港(瓜德尔港)
- 术语：半衰期(丰意期)、放射性衰变(女变)、黑洞(黑润)
- 化学名：甲醛(甲醒)、碳酸钙(CaCOH)₂

### Step 3: Factual Verification

For each corrected knowledge point, verify against established facts:

**Verification priorities (by severity):**

1. **P0 - Hard facts that must be accurate:**
   - Historical dates, names, places
   - Scientific definitions and laws
   - Geographic data (largest, highest, etc.)
   - Legal provisions and official titles
   - Named entities (people, organizations, events)

2. **P1 - General accuracy:**
   - Statistical claims (ranks, percentages)
   - Classification categories
   - "First" / "largest" / "highest" claims

3. **P2 - Reasonable approximations:**
   - General descriptions
   - Common knowledge statements

**Common factual errors in exam notes:**
- Wrong attribution: e.g., "伽利略" for gravity laws → should be "牛顿"
- Confused entities: e.g., "活性炭干燥是化学反应" → is physical adsorption
- Outdated claims: e.g., "泰国是最大稻米出口国" → was India in recent years
- Incomplete information: e.g., missing context, qualifiers, or exceptions

**When uncertain about a fact**, use web_search to verify. Mark uncertain items with [待核实] in the output.

### Step 4: Categorize Knowledge Points

After correction and verification, categorize each item. Use the following category system for 考公 materials:

**Default categories:**
- 政治与时政 (Politics & Current Affairs)
- 经济常识 (Economics)
- 法律知识 (Law)
- 历史知识 (History)
- 人文与文学 (Humanities & Literature)
- 科技与航天 (Science & Technology)
- 地理知识 (Geography)
- 生物与植物 (Biology & Botany)
- 医学与急救 (Medicine & First Aid)
- 化学与物理 (Chemistry & Physics)
- 体育常识 (Sports)
- 文化与民俗 (Culture & Folklore)
- 其他 (Other)

**Categorization rules:**
- Each item belongs to exactly one primary category
- If an item spans multiple categories, pick the most prominent one
- Sub-categories can be noted within each item for finer organization

### Step 5: Generate Document

Use the bundled Python script `scripts/gen_docx.py` to generate a Word document.

**Script usage:**
```bash
python scripts/gen_docx.py --title "文档标题" --output "输出路径.docx"
```

The script reads a JSON file containing the processed knowledge items. The JSON format:

```json
{
  "title": "文档标题",
  "items": [
    {
      "category": "地理知识",
      "content": "中国最大淡水湖是鄱阳湖，位于江西省。",
      "original": "中国最大淡水湖：鄱阳湖(江工西)",
      "corrections": ["江工西→江西省"]
    }
  ]
}
```

**JSON file path:** Pass via `--input` flag or pipe to stdin.

**Document formatting:**
- Title in bold, centered, 18pt
- Category headers in bold, 14pt, colored
- Items numbered within each category
- Corrections shown as footnotes or inline annotations
- Font: 微软雅黑 for Chinese, consistent sizing

**Alternative: If python-docx is not available**, fall back to generating a well-formatted Markdown file, then use the `docx` skill to convert.

### Step 6: Deliver and Summarize

1. Deliver the generated document to the user via `deliver_attachments`.
2. Provide a summary including:
   - Total items processed
   - Number of OCR/typo corrections made (with examples)
   - Number of factual corrections made (with examples)
   - Category breakdown (item count per category)
   - Any items marked [待核实] requiring user confirmation

## Error Handling

- If raw text is from an image, use `read_file` to view it first, then process.
- If a fact cannot be verified, mark it [待核实] and list it in the summary for user review.
- If the script fails, fall back to Markdown generation.
- Always preserve the original text alongside corrections so the user can review changes.

## Quality Checklist

Before delivering, verify:
- [ ] All OCR errors identified and corrected
- [ ] All factual claims verified (or marked [待核实])
- [ ] Each item assigned to exactly one category
- [ ] Categories sorted logically
- [ ] Document formatting is clean and readable
- [ ] Summary of changes provided to user
