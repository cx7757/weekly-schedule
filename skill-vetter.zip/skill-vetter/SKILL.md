---
name: skill-vetter
description: "This skill should be used BEFORE installing, importing, or activating any third-party or user-provided skill. It performs a structured security and quality audit on the skill SKILL.md and all bundled files in scripts, references, and assets folders, producing a risk-graded report so the user can make an informed decision. Typical triggers: install this skill, import skill from zip, add a new skill, help me use this SKILL.md. Do NOT use for skills already installed and in active use."
---

# Skill Vetter — Third-Party Skill Security & Quality Audit

## Purpose

Perform a comprehensive security and quality audit on any skill package before it is installed into the user's WorkBuddy environment. Surface risks, provide a graded report, and require explicit user confirmation before proceeding with installation.

## When to Use

Load this skill whenever:
- The user wants to install, import, download, or activate a skill from any external source
- The user pastes or references a SKILL.md that did not come from the official WorkBuddy skill store
- The user says anything like "install this skill", "add skill", "enable skill from zip/URL/folder"

## Audit Process

### Step 1 — Collect Skill Materials

Locate and read all files in the skill package:
1. `SKILL.md` — always required
2. `scripts/*` — all executable files (Python, Bash, PowerShell, JS, etc.)
3. `references/*` — all documentation/reference files
4. `assets/*` — all asset files (templates, fonts, images, binaries)

If the skill is provided as a zip, extract it to a temp directory and then read all files.

### Step 2 — Run Security Checks

Check each file against the following risk categories:

#### P0 — Critical (Block + Strongly Warn)

| Check | What to Look For |
|-------|-----------------|
| **Credential exfiltration** | Scripts that read env vars, API keys, tokens, .ssh, .aws, browser cookies, keychain/credential stores and send them to remote servers |
| **Destructive file operations** | `rm -rf`, `shutil.rmtree`, `del /S /Q`, broad wildcard deletes on home/system directories |
| **Remote code execution** | `eval()`, `exec()`, `subprocess` / `os.system` calling URLs, downloading and running external scripts at runtime |
| **Privilege escalation** | `sudo`, UAC bypass, registry edits (`HKLM`), modifying system PATH, service installation |
| **Data exfiltration** | Reading workspace files / user documents and POSTing to external endpoints |
| **Obfuscated code** | Base64-decoded `exec`, hex-encoded strings, minified one-liners that hide intent |

#### P1 — Moderate (Warn + Require Confirmation)

| Check | What to Look For |
|-------|-----------------|
| **Unnecessary network access** | `requests`, `urllib`, `fetch` calls not required by the stated skill purpose |
| **Broad file system access** | Reads/writes outside the workspace root without documented justification |
| **Hardcoded endpoints** | IP addresses, non-official domains, or tracking pixels in scripts |
| **Opaque binaries** | `.exe`, `.dll`, `.so`, pre-compiled wheels with no source |
| **Overly broad permissions request** | Skill description claims it needs OS-level or root access |
| **No author / provenance info** | Skill has no author, source URL, or version — impossible to verify origin |

#### P2 — Safe (Proceed Normally)

Skill passes all P0 and P1 checks with no issues found. May still include minor notes.

### Step 3 — Quality Checks

Beyond security, evaluate the skill's usefulness and reliability:

- **Name & description clarity**: Is the trigger condition clear? Would WorkBuddy know when to load this skill?
- **Instruction completeness**: Does SKILL.md explain the full workflow, or does it leave large gaps?
- **Resource integrity**: Do references/assets actually exist in the package, or are there broken references?
- **Redundancy**: Does this skill duplicate an already-installed skill? If so, flag it.

### Step 4 — Generate Audit Report

Produce a structured report with the following sections:

```
## Skill Audit Report: <skill-name>

### Summary
Risk Level: P0 / P1 / P2
Recommendation: Block / Warn / Approve

### Security Findings
[List each finding with: severity | file | line (if applicable) | description]

### Quality Notes
[Non-blocking observations about skill effectiveness]

### File Inventory
[List all audited files with size and type]

### Verdict
[One paragraph explaining the overall recommendation]
```

### Step 5 — Act on Verdict

| Risk Level | Action |
|-----------|--------|
| **P0** | Display report, **STRONGLY WARN** in bold red language, state "Installation blocked due to critical security risks." Require explicit double-confirmation ("type YES to proceed anyway") before allowing installation. |
| **P1** | Display report, warn the user, ask "Do you want to proceed with installation despite the above warnings?" Wait for explicit yes/no. |
| **P2** | Display report, state "No security issues found. Safe to install." Proceed with installation. |

## Important Notes

- Always audit ALL files in the package, not just SKILL.md
- When in doubt about a code pattern, flag it as P1 and explain the concern
- Never execute scripts during the audit — read and analyze statically only
- If the skill zip is corrupted or unreadable, report that and stop
